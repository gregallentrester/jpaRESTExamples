package net.greg.rest;

public interface TransientMarker {  }
